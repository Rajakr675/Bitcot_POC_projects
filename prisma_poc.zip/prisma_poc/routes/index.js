import { Router } from "express";
import UserRouter from "./userRoutes"
export const appRouter=Router()

appRouter.use("/user",UserRouter)

