import {Router} from "express";
import { createUser } from "../controller/User";

export const UserRouter=Router();

UserRouter.post("/",createUser);



